This is the code for the FRC Robot Jones-3
We use a command based robot

Made by the BOGO Bots Team, Topsail High School


